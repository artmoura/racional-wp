<!DOCTYPE html>
<html>
	<head>
		<title>Redirecting...</title>
		<meta http-equiv="refresh" content="0;url=http://www.racionalconsultoria.com.br/feed/atom/">
	</head>
	<body>
		<script type="text/javascript">
			window.location = "http://www.racionalconsultoria.com.br/feed/atom/";
		</script>

		<p>You are being redirected to <a href="http://www.racionalconsultoria.com.br/feed/atom/">http://www.racionalconsultoria.com.br/feed/atom/</a></p>
	</body>
</html>
